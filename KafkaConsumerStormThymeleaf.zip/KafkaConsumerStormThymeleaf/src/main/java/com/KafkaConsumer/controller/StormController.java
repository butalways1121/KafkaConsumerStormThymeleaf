package com.KafkaConsumer.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.TableName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.KafkaConsumer.entity.HbaseEntity;
import com.KafkaConsumer.entity.InfoGet;
import com.KafkaConsumer.hbaseutil.HBaseUtil;
import com.KafkaConsumer.service.InfoGetService;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@Controller
public class StormController {
	
	@Autowired
	private InfoGetService infoGetService;

	@RequestMapping("/list")
	public String toList(Model model) {
		List<InfoGet> infos = infoGetService.findAll();
		model.addAttribute("infos",infos);
		return "user/list";
	}
	
	@RequestMapping("/toAdd")
	public String toAdd(Model model) {
		return "user/add";
	}
	@RequestMapping("/addUser")
	public String addUser(InfoGet infoGet) {
		infoGetService.add(infoGet);
		return "redirect:/list";
	}
	@RequestMapping("/delete")
	public String delete(int id) {
		infoGetService.delete(id);
		return "redirect:/list";
	}
	@RequestMapping("/toEdit")
	public String toEdit(Model model,int id) {
		InfoGet info = infoGetService.findById(id);
	     model.addAttribute("info", info);
		return "user/edit";
	}
	@RequestMapping("/edit")
	public String edit(InfoGet infoGet) {
		infoGetService.update(infoGet);
		return "redirect:/list";
	}
	@RequestMapping("/toHbase")
	public String toHbase(Model model) throws IOException {
		TableName[] tables = HBaseUtil.getListTable();  //获取数组形式的所有表名
		List<HbaseEntity> results =new ArrayList<HbaseEntity>();  //定义一个数组形式的hbaseEntity对象result用以存储查询到的结果
		for (TableName table : tables) {//遍历表名，将每一个表名添加到select()出的数组对象
			//HBaseUtil的select()方法查询到没有表名属性的对象数组entitys，select()传入的参数是String，使用tableName自带的方法转换成String类型
			List<Map<String, Object>> entitys =  HBaseUtil.select(table.getNameAsString());
			for (Map<String, Object> entity : entitys) {//对于每一个table中entitys的每个对象，添加tableName属性的值
				String jsonString = JSON.toJSONString(entity); //先将entity转换成JsonString
				HbaseEntity parseObject = JSONObject.parseObject(jsonString,HbaseEntity.class);//在将JsonString转换成对象
				parseObject.setTableName(table.getNameAsString());//添加对象tableName属性的值
				results.add(parseObject);//将对象存储到reslut中
			}
		}
		model.addAttribute("entitys", results);
		for(HbaseEntity result:results) {
			infoGetService.addToHbase(result);
		}
		return "user/hbase";
	}
	@RequestMapping("/toHbaseInsert")
	public String toHbaseInsert(Model model) {
		return "user/hbaseInsert";
	}
	
	@RequestMapping("/insertHbase")
	public String insertHbase(HbaseEntity hbaseEntity) throws IOException {
		HBaseUtil.insert(hbaseEntity.getTableName(),hbaseEntity.getRowKey(),hbaseEntity.getFamily(), hbaseEntity.getQualifier(),hbaseEntity.getValue());
		return "redirect:/toHbase";//redirect重定向到方法
	}
	
}
