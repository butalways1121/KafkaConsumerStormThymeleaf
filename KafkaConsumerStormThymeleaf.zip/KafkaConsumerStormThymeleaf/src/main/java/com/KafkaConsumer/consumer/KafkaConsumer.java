//package com.KafkaConsumer.consumer;
//
//import java.io.IOException;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.KafkaConsumer.entity.InfoGet;
//import com.KafkaConsumer.service.InfoGetService;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.stereotype.Component;

/**
 * 消费者 使用@KafkaListener注解,可以指定:主题,分区,消费组
 * 
 * @author 20180877
 *
 */
//@Component
//public class KafkaConsumer {
//	@Autowired
//	private ObjectMapper objectMapper;// ObjectMapper类是Jackson库的主要类。它提供一些功能将转换成Java对象匹配JSON结构，反之亦然。
//	@Autowired
//	private InfoGetService infoGetService;
//
//	// 在方法上使用@KafkaListener注解，并指定要消费的topic（也可以指定消费组以及分区号，支持正则表达式匹配），这样，消费者一旦启动，就会监听kafka服务器上的topic，实时进行消费消息
//	@KafkaListener(topics = { "Kafka-111" })
//	public void insert(String message) throws IOException {
//		System.out.println("Kafka-111--消费消息:" + message);
////		读取生产者的所有数据
////		InfoGet infoGet = objectMapper.readValue(message, InfoGet[].class)[0];
////		System.out.println("获取id: " + infoGet.getId());
////		infoGetService.insert(infoGet.getId(), infoGet.getName(), infoGet.getAge());
////		读取生产者的所有数据
//		InfoGet[] infoGets = objectMapper.readValue(message, InfoGet[].class);
//		for(InfoGet infoGet:infoGets) {
//			System.out.println("获取id: " + infoGet.getId());
//			infoGetService.insert(infoGet.getId(),infoGet.getName(),infoGet.getAge());
//		}
//	}
//}
