package com.KafkaConsumer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.KafkaConsumer.entity.HbaseEntity;
import com.KafkaConsumer.entity.InfoGet;

@Mapper
public interface InfoGetDao {
	boolean insert(List<InfoGet> entityList) throws Exception;//批量插入数据
	
	@Select("select * from infoget")
	List<InfoGet> findAll();
	
	@Insert("insert into infoget(name,age) values(#{name},#{age})")
	void add(InfoGet infoGet);
	
	@Delete("delete from infoget where id=#{id}")
	void delete(int id);
	
	@Select("select id,name,age from infoget where id=#{id}")
	InfoGet findById(int id);
	
	@Update("update infoget set name=#{name},age=#{age} where id=#{id}")
	void update(InfoGet infoGet);
	
	@Insert("insert into hbase(tableName,qualifier,family,value,rowKey,timestamp) values(#{tableName},#{qualifier},#{family},#{value},#{rowKey},#{timestamp})")
	boolean addToHbase(HbaseEntity hbaseEntity);
}
