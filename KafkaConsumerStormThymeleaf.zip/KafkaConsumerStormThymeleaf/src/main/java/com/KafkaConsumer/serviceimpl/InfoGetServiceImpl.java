package com.KafkaConsumer.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.KafkaConsumer.dao.InfoGetDao;
import com.KafkaConsumer.entity.HbaseEntity;
import com.KafkaConsumer.entity.InfoGet;
import com.KafkaConsumer.service.InfoGetService;

@Service
public class InfoGetServiceImpl implements InfoGetService{

	@Autowired
	private InfoGetDao infoGetDao;
	
	@Override
	public boolean insert(List<InfoGet> entityList) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			infoGetDao.insert(entityList);
			flag = true;
			System.out.println("数据写入成功！");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("数据写入失败！");
		}
		return flag;
	}

	@Override
	public List<InfoGet> findAll() {
		// TODO 自动生成的方法存根
		return infoGetDao.findAll();
	}

	@Override
	public boolean add(InfoGet infoGet) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			infoGetDao.add(infoGet);
			flag = true;
			System.out.println("数据插入成功！");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("数据插入失败！");
		}
		return flag;
	}

	@Override
	public boolean delete(int id) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			infoGetDao.delete(id);
			flag = true;
			System.out.println("数据删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("数据删除失败！");
		}
		return flag;
	}

	@Override
	public InfoGet findById(int id) {
		// TODO 自动生成的方法存根
		return infoGetDao.findById(id);
	}

	@Override
	public void update(InfoGet infoGet) {
		// TODO 自动生成的方法存根
		infoGetDao.update(infoGet);
		System.out.println("更新成功！");
	}

	@Override
	public boolean addToHbase(HbaseEntity hbaseEntity) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			infoGetDao.addToHbase(hbaseEntity);
			flag = true;
			System.out.println("数据磁写入成功！");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("数据写入失败！");
		}
		return flag;
	}

}