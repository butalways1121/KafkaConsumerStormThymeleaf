package com.KafkaConsumer.service;

import java.util.List;

import com.KafkaConsumer.entity.HbaseEntity;
import com.KafkaConsumer.entity.InfoGet;

public interface InfoGetService {
	boolean insert(List<InfoGet> entityList); 
	List<InfoGet> findAll();
	boolean add(InfoGet infoGet);
	boolean delete(int id);
	InfoGet findById(int id);
	void update(InfoGet infoGet);
	boolean addToHbase(HbaseEntity hbaseEntity);
}