package com.KafkaConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.KafkaConsumer.storm.Topology;
import com.KafkaConsumer.util.GetSpringBean;


/**
 * Hello world!
 *
 */
@SpringBootApplication
public class App 
{
	public static void main(String[] args) {
		// 启动嵌入式的 Tomcat 并初始化 Spring 环境及其各 Spring 组件
		//将storm的Topology写在SpringBoot启动的主类中，随着SpringBoot启动而启动
		ConfigurableApplicationContext context = SpringApplication.run(App.class, args);
		GetSpringBean springBean=new GetSpringBean();//bolt和spout类无法使用spring注解,使用动态获取bean的方法之后，可以成功启动storm
		springBean.setApplicationContext(context);//通过这句获取到Spring管理的所有的bean
		Topology app = context.getBean(Topology.class);//获取到不能使用Spring注解的bean
		app.runStorm(args);
	}
}
