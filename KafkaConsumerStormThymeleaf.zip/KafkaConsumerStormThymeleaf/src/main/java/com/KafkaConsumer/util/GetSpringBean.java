package com.KafkaConsumer.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


/**
 * 
* @Title: GetSpringBean
* @Description:
* spring动态获取bean实现 
* @Version:1.0.0  
* @author pancm
* @date 2018年5月8日
 */
//手动从spring容器获取bean
//工具类实现ApplicationContextAware接口，并重写setApplicationContext(ApplicationContext applicationContext)方法，
//在工具类中使用@Component注解让spring进行管理。spring容器在启动的时候，会调用setApplicationContext()方法将ApplicationContext 对象设置进去。
public class GetSpringBean implements ApplicationContextAware{

	private static ApplicationContext context;

	public static Object getBean(String name) {
		return context.getBean(name);
	}

	public static <T> T getBean(Class<T> c) {

		return context.getBean(c);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		if(applicationContext!=null){
			context = applicationContext;
		}
	}

}
